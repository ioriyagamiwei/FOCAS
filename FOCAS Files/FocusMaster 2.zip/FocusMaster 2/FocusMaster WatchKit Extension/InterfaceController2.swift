
//
//  InterfaceController2.swift
//  FocusMaster
//
//  Created by Storm Lim on 17/10/16.
//  Copyright © 2016 J.Lim. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController2: WKInterfaceController {

    @IBOutlet var text: WKInterfaceLabel!
    
    var quotes = ["If Not Us, Who?", "If Not now, when?", "You must do the thing you think you cannot do.", "The best way out is always through", "I can and i will", "You are stronger than you think", "Never give up", "work hard dream big", "Hope is stronger than fear", "Be happy be bright be you", "worry less smile more", "life is a one time offer, use it well", "Tonight, I dream. Tomorrow I do", "Losers quit when they fail", "Winners fail until they succeed", "The future starts today not tomorrow", "Doubts kill more dreams than failure ever will", "Success is the sum of small efforts repeated day in day out", "Dreams don't work unless you do", "I'll find strength in pain", "Mistakes are proof you're trying", "The greater your storm the brighter your rainbow", "life begins at the end of your comfort zone", "be you and stay you", "Don't just fly, Soar", "Never stop dreaming", "Dream big", "Only those who attempt the absurd will achieve the impossible", "all things are possible  believe", "Our thoughts determine our reality", "Be the change you wish to see in the world", "Aspire to inspire before we expire", "A jug fills drop by drop", "Difficult roads often lead to beautiful destinations", "Hope is the heartbeat of the soul", "Wherever you go, go with all your heart", "Pain makes people change", "Doubt your Doubts before you doubt yourself", "nothing great ever came that easy", "It is possible", "What ever you decide to do, make sure it makes you happy", "Turn your wounds into wisdom", "Never regret anything", "be the best version of you", "Do things everyday that scares you", "Never let go of your dreams", "We become what we think about", "Live what you love", "The best is yet to come", "Success is the best revenge", "make a wish take a chance make a change", "Dream big and dare to fail", "You woke up, You're a miracle", "all you need is love", "What you are looking for is not out there it's in you", "It is better to fail aiming high than succeed aiming low", "don't count the days make the days count", "Don't regret the pass learn from it", "You Only Live Once", "You can do anything", "Life doesn't get easier you just get stronger", "It just takes some time", "Stars can't shine without darkness", "I never lose. I either win or I learn", "If you do what you always did you will get what you always get", "wake up with determination. go to be with satisfaction", "enjoy every sandwich", "The obstacle is the path", "every moment matters", "And now i'll do what's best for me", "enjoy the little things", "we rise by lifting others", "believe you can and you're halfway there", "be a rainbow in someone else's cloud.", "Find yourself, and be that", "you can make a difference if you try", "In helping others we help ourselves", "Having hope will give you courage", "What's done is done.", "If you never try you'll never know", "When nothing goes right...  go left", "Stay Strong", "I'm batman", "Life is too short to wait", "I will win, not immediately but definitely", "Enjoy every moment as it comes.", "die with memories not dreams", "and now i'll do what's best for me", "Hold on, pain ends", "You can only do your best, and if they can't appreciate that, it's their problem.", "It goes on", "To be old and wise, you must first have to be young and stupid", "Don't stop until you're proud", "Keep moving forward", "Somedays you just have to create your own sunshine", "You are your only limit", "nothing worth comes easy", "Make yourself a priority", "Life is tough, but so are you.", "Inhale the future, exhale the pass."]
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        text.setText(quotes[Int(arc4random_uniform(UInt32(quotes.count)))])
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        text.setText(quotes[Int(arc4random_uniform(UInt32(quotes.count)))])
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
