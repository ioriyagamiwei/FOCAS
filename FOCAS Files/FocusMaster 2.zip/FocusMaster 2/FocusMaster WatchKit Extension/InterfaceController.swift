//
//  InterfaceController.swift
//  FocusMaster WatchKit Extension
//
//  Created by Storm Lim on 28/9/16.
//  Copyright © 2016 J.Lim. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController, WCSessionDelegate {
    /** Called when the session has completed activation. If session state is WCSessionActivationStateNotActivated there will be an error with more details. */
    @available(watchOS 2.2, *)
    public func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    @IBOutlet var time: WKInterfaceLabel!
    
    var timer = Timer()
    var hr: Int = 0
    var min: Int = 0
    var sec: Int = 0
    
    var secStr: String = ""
    var minStr: String = ""
    
    let session = WCSession.default()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        if(WCSession.isSupported()){
            session.delegate = self
            session.activate()
        }
    }
    
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String : Any]){
        let started : String = applicationContext["started"] as! String
        if started == "1" {
            DispatchQueue.main.async(execute: { () -> Void in
                self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(InterfaceController.track), userInfo: nil, repeats: true)
            })
        } else {
            timer.invalidate()
        }
    }
    
    func track() {
        if sec != 60 {
            sec += 1
        } else {
            sec = 0
            if min != 60 {
                min += 1
            } else {
                min = 0
                hr += 1
            }
        }
        
        if sec < 10 {
            secStr = "0\(sec)"
        } else {
            secStr = "\(sec)"
        }
        
        if min < 10 {
            minStr = "0\(min)"
        } else {
            minStr = "\(min)"
        }
        
        time.setText("\(minStr)\n\(secStr)")
        
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
}
