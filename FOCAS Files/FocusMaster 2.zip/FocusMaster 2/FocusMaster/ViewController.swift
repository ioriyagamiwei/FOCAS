//
//  ViewController.swift
//  FocusMaster
//
//  Created by Storm Lim on 28/9/16.
//  Copyright © 2016 J.Lim. All rights reserved.
//

import UIKit
import WatchConnectivity
import FBSDKCoreKit
import FBSDKLoginKit

class ViewController: UIViewController, WCSessionDelegate {
    /** Called when all delegate callbacks for the previously selected watch has occurred. The session can be re-activated for the now selected watch using activateSession. */
    @available(iOS 9.3, *)
    public func sessionDidDeactivate(_ session: WCSession) {
        
    }

    /** Called when the session can no longer be used to modify or add any new transfers and, all interactive messages will be cancelled, but delegate callbacks for background transfers can still occur. This will happen when the selected watch is being changed. */
    @available(iOS 9.3, *)
    public func sessionDidBecomeInactive(_ session: WCSession) {
        
    }

    /** Called when the session has completed activation. If session state is WCSessionActivationStateNotActivated there will be an error with more details. */
    @available(iOS 9.3, *)
    public func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    let Just = JustOf<HTTP>()
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var connection: UILabel!
    @IBOutlet weak var watchIcon: UIImageView!
    
    var i = 0
    
    var started = "0" //0 false - 1 true
    var quotes = ["If Not Us, Who?","If Not now, when?","You must do\nthe thing you\nthink you\ncannot do.","The best way out is always through","I can\nand\ni will","You are stronger than you think","Never give up","work\nhard\ndream\nbig","Hope is stronger than fear","Be happy\nbe bright\nbe you","worry less\nsmile more","life is a one time offer, use it well","Tonight, I dream.\nTomorrow I do","Losers quit when they fail","Winners fail until they succeed","The future starts today\nnot tomorrow","Doubts kill more dreams\nthan failure ever will","Success is the sum of small efforts repeated day in day out","Dreams don't work unless you do","You will find strength in pain","Mistakes are proof you're trying","The greater your storm the brighter your rainbow","life begins at the end of your comfort zone","be you\nand\nstay you","Don't just fly,\nSoar","Never\nstop\ndreaming","Dream big","Only those who attempt the absurd\nwill achieve the impossible","all things are possible\n\nbelieve","Our thoughts\ndetermine\nour reality","Be the change you wish to see in the world","Aspire\nto\ninspire\nbefore we\nexpire","A jug fills drop by drop","Difficult roads often lead to beautiful destinations","Hope is the heartbeat of the soul","Wherever you go,\ngo with all your heart","Pain makes people change","Doubt your\nDoubts\nbefore you doubt yourself","nothing great ever came that easy","It is\npossible","What ever you\ndecide to do,\nmake sure it\nmakes you happy","Turn your wounds into wisdom","Never\nregret\nanything","be the best version of you","Do things everyday that scares you","Never let go of your dreams","We become what we think about","Live what you love","The best is yet to come","Success is the best revenge","make a wish\ntake a chance\nmake a change","Dream big\nand\ndare to fail","You woke up,\nYou're a miracle","all you need is love","What you are looking for is not out there\nit's in you","It is better to fail aiming high\nthan succeed aiming low","don't count the days\nmake the days count","Don't regret the pass\nlearn from it","You\nOnly\nLive\nOnce","You can do anything","Life doesn't get easier\nyou just get stronger","It just takes some time","Stars can't shine without darkness","I never lose.\nI either win or\nI learn","If you do what you always did\nyou will get what you always get","wake up with determination.\ngo to be with satisfaction","enjoy\nevery\nsandwich","The obstacle is the path","every moment matters","And now i'll do\nwhat's best for me","enjoy the little things","we rise by lifting others","believe you can\nand\nyou're halfway there","be a rainbow in someone else's cloud.","Find yourself,\nand be that","you can make a difference\nif you try","In helping others, we help ourselves","Having hope will give you courage","What's done\nis done.","If you never try\nyou'll never know","When nothing goes right...\n\ngo left","Stay\nStrong","I'm batman","Life is too short\nto wait","I will win,\nnot immediately\nbut definitely","Enjoy every moment as it comes.","die with memories\nnot dreams","and now i'll do what's best for me","Hold on,\npain ends","You can only do your best,\nand if they can't appreciate that, it's their problem.","It goes on","To be old and wise,\nyou must first have to be young and stupid","Don't\nstop\nuntil\nyou're\nproud","Keep moving forward","Somedays you just have to create your own sunshine","You are\nyour only\nlimit","nothing worth comes easy","Make yourself a priority","Life is tough,\nbut so are you.","Inhale the future,\nexhale the pass."]
    
    var brightness = CGFloat()
    
    var session: WCSession?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        FBSDKProfile.enableUpdates(onAccessTokenChange: true)
//        print("\n\n", FBSDKProfile.current().firstName, "\n\n")
        
        if WCSession.isSupported() {
            session = WCSession.default()
            session?.delegate = self
            session?.activate()
        }
        
        if session?.isPaired == true {
            connection.text = "Connected"
        } else {
            connection.text = "Not Connected"
        }
        self.watchIcon.layer.cornerRadius = self.watchIcon.frame.width/2
        self.watchIcon.clipsToBounds = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.rotated), name: NSNotification.Name.UIDeviceOrientationDidChange, object: nil)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(ViewController.watch))
        watchIcon.isUserInteractionEnabled = true
        watchIcon.addGestureRecognizer(tap)
    }
    
    func post() {
        var request = URLRequest(url: URL(string: "http://graph.facebook.com")!)
        request.httpMethod = "POST"
        let postString = "/{user-id}/feed?message='message'&access_token='\(FBSDKAccessToken.current())'"
        request.httpBody = postString.data(using: .utf8)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
        }
        task.resume()
    }
    
    func postReq(_ str: String) {
//        let params: [AnyHashable: Any] = ["message": "This is a test message"]
//        /* make the API call */
//        let request = FBSDKGraphRequest(graphPath: "/{from.id}_{status-id}", parameters: params, httpMethod: "POST")
//        request?.start(completionHandler: { (connection, requestConnection, error) in
//            print("c: ", connection, "\n\n")
//            print("rq: ", requestConnection, "\n\n")
//            print("e", error, "\n\n")
//        })
        
        if FBSDKAccessToken.current().hasGranted("publish_actions") {
            FBSDKGraphRequest(graphPath: "me/feed", parameters: ["message": str], tokenString: FBSDKAccessToken.current().tokenString, version: "v2.8", httpMethod: "POST").start(completionHandler: { (connection, request, error) in
                print("\n\n\nc:", connection, "\n\n\nr:", request, "\n\n\nerr:", error)
            })
        }

    }
    
    func watch() {
        label.text = "Connect to your\nApple Watch\n(If you own one)"
    }
    
    override func viewDidAppear(_ animated: Bool) {
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        
    }
    
    func rotated() {
        if UIDevice.current.orientation.rawValue == 2 || UIDevice.current.orientation.rawValue == 6 {
            started = "1"
            
            view.backgroundColor = UIColor.black
            watchIcon.alpha = 0
            brightness = UIScreen.main.brightness
            UIScreen.main.brightness = 0
            postReq("Working Hard, do not disturb.")
        } else {
            view.backgroundColor = UIColor.white
            watchIcon.alpha = 1
            if started == "1" {
                label.text = quotes[Int(arc4random_uniform(UInt32(quotes.count)))]
                started = "0"
                UIScreen.main.brightness = brightness
                i += 1
            }
            postReq("Slacking off, motivate me.")
        }
        if let validSession = session {
            let iPhoneAppContext = ["started": started]
            do {
                try validSession.updateApplicationContext(iPhoneAppContext)
            } catch {
                
            }
        }
    }
    
}

