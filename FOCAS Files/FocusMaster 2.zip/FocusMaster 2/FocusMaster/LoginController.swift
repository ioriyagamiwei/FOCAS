//
//  LoginController.swift
//  FocusMaster
//
//  Created by bob on 4/3/17.
//  Copyright © 2017 J.Lim. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit

class LoginController: UIViewController, FBSDKLoginButtonDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        if FBSDKAccessToken.current() == nil {
            print("bad")
        } else {
            performSegue(withIdentifier: "doneLogin", sender: self)
        }
        
        // Do any additional setup after loading the view.
        let loginBtn = FBSDKLoginButton()
        loginBtn.center = view.center
        loginBtn.readPermissions = ["public_profile", "email", "user_friends", "user_post"]
        loginBtn.publishPermissions = ["publish_actions"]
        loginBtn.delegate = self
        view.addSubview(loginBtn)
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if error != nil {
            print("error")
        } else if result.isCancelled {
            print("cancelled")
        } else {
            print(FBSDKAccessToken.current())
            performSegue(withIdentifier: "doneLogin", sender: self)
        }
    }

    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("sad")
    }
    
}
